FastCursor
MACRO FastCursor @Name
DECLARE @Name CURSOR LOCAL FAST_FORWARD for 
