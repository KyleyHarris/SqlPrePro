_body
MACRO _body @block
$PROC_BEGIN
  @block
$PROC_END
ENDMACRO
