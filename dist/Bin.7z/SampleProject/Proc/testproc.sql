testproc
create procedure testproc  as
begin
   select 1
end
